
function celebrate() {
    let confetti = document.getElementById("confetti");
    confetti.innerHTML = "🎉 Жолда кездескенше! 🎉";
    confetti.style.fontSize = "30px";
    confetti.style.marginTop = "20px";
}
